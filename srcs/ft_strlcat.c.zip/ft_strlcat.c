/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kachiote <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/15 18:02:20 by kachiote          #+#    #+#             */
/*   Updated: 2019/09/17 20:07:33 by kachiote         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

size_t	ft_strlcat(char *dst, const char *src, size_t size)
{
	size_t	dstlen;
	size_t	srclen;
	char	*bdst;
	const char	*bsrc;

	bdst = dst;
	dstlen = 0;
	while ((*dst) && (size))
	{
		dst++;
		dstlen++;
		size--;
	}
	srclen = ft_strlen(src);
	if (size - srclen < 1)
		return (dstlen + srclen);
	bsrc = src;
	while ((*src) && (size > 1))
	{
		*dst = *src;
		dst++;
		src++;
	}
	*dst = '\0';
	return (dstlen + (src - bsrc));
}
